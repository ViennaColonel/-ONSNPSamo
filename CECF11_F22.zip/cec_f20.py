import sys
import math
import time
import copy
import random
import numpy as np
from random import randint
import matplotlib.pyplot as plt
from scipy.io import savemat
TIMES = 0
D = 10
GlobalResultList = []

class Logger(object):
    def __init__(self, fileN="Default.log"):
        self.terminal = sys.stdout
        self.log = open(fileN, "a")

    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)

    def flush(self):
        pass
sys.stdout = Logger("./data/f10_D" + str(D) + "_T" + str(TIMES) + ".txt")

with open('./ShiftingandRotation/shift_data_10.txt', 'rt', encoding='utf-8') as f:
    x = f.read()
O10 = list(map(float, (x.split()[0:10])))
O10 = np.array(O10)
O30 = list(map(float, (x.split()[0:30])))
O30 = np.array(O30)
O50 = list(map(float, (x.split()[0:50])))
O50 = np.array(O50)
O100 = list(map(float, (x.split()[0:100])))

M10 = []
M30 = []
M50 = []
with open('./ShiftingandRotation/M_10_D10.txt', 'rt', encoding='utf-8') as f:
    x = f.readlines()
for j in x:
    M10.append(list(map(float, j.split())))
M10 = np.array(M10)
with open('./ShiftingandRotation/M_10_D30.txt', 'rt', encoding='utf-8') as f:
    x = f.readlines()
for j in x:
    M30.append(list(map(float, j.split())))
M30 = np.array(M30)
with open('./ShiftingandRotation/M_10_D50.txt', 'rt', encoding='utf-8') as f:
    x = f.readlines()
for j in x:
    M50.append(list(map(float, j.split())))
M50 = np.array(M50)

for loop in range(20):

    badFitnessList = []
    meanFitnessList = []
    TIMES= TIMES + 1
    bestSolution = 100
    caculationErrorList = []

    def getNowTimestamp():
        now = time.time()

        return int(round(now * 1000))


    def DpaByp(E,gen):
        xishu = 1/((len(E)-1)*(len(E)-2))

        H = len(E)
        m = len(E[0])
        temsum = 0
        for i in range(1,H-1):
            for j in range(i+1,H):
                for k in range(1,m):
                    temsum = temsum + (1/m)*(abs(E[i][k]-E[j][k]))

        return xishu*temsum

    def getOriginVariable_media(VariablelistMin,VariablelistMax,popsize=50):

        medianlist = [(VariablelistMax[k]-VariablelistMin[k])/2 for k in range(len(VariablelistMin))]

        VariablesMatrix = [[medianlist[j] for j in range(len(VariablelistMin))] for i in range(popsize)]

        return VariablesMatrix

    def getOriginVariableRandom(VariablelistMin,VariablelistMax,popsize=50):
        VariablesMatrix = [[0 for j in range(len(VariablelistMin))] for i in range(popsize)]
        for i in range(popsize):
            for j in range(len(VariablelistMin)):
                VariablesMatrix[i][j] = getRandNum(VariablelistMin[j],VariablelistMax[j])

        return VariablesMatrix


    def makeVariation(VariablesMatrix,VariablelistMin,VariablelistMax,Pjm):
        for i in range(len(VariablesMatrix)):
            for j in range(len(VariablesMatrix[0])):
                if np.random.rand() < Pjm:
                    VariablesMatrix[i][j] = getRandNum(VariablelistMin[j],VariablelistMax[j])

        return VariablesMatrix


    def makeVariation2(P,VariablelistMin,VariablelistMax,Pjm,VariablelistMatrix_M,externalarchiveMatrix,iteration,F,rand_p_a,rand_p_b):

        bestindex, bestFitness, fitnessMatrix = computeFitness(P)
        Q = copy.deepcopy(P)

        index = np.argsort(fitnessMatrix)
        bestindexofJA = index[randint(0, round(len(index)*0.2))]
        weight1 = 0
        weight2 = 0
        weight3 = 0
        countselect1 = 0
        countselect2 = 0
        countselect3 = 0

        T = copy.deepcopy(P)
        for i in range(len(P)):
            if np.random.rand() >= Pjm:
                continue

            k1=math.ceil((len(P)-1)*np.random.rand())
            while (k1==i) or (k1==bestindex):
                k1=math.ceil((len(P)-1)*np.random.rand())
            k2=math.ceil((len(P)-1)*np.random.rand())
            while (k2==i) or (k2==k1) or (k2==bestindex):
                k2=math.ceil((len(P)-1)*np.random.rand())
            k3=math.ceil((len(P)-1)*np.random.rand())
            while (k3==i) or (k3==k2) or (k3==k1) or (k3==bestindex):
                k3=math.ceil((len(P)-1)*np.random.rand())
            k4=math.ceil((len(P)-1)*np.random.rand())
            while (k4==i) or (k4==k3) or (k4==k2) or (k4==k1) or (k4==bestindex):
                k4=math.ceil((len(P)-1)*np.random.rand())
            k5=math.ceil((len(P)-1)*np.random.rand())
            while (k5==i) or (k5==k4) or (k5==k3) or (k5==k2) or (k5==k1) or (k5==bestindex):
                k5=math.ceil((len(P)-1)*np.random.rand())

            myindexs = [k3, k1, k2, k4, k5]
            myindexs1 = [i, k1, k2]

            if isinstance(F[i],int) is True or isinstance(F[i],float) is True:
               Fi = F[i]
            else:
               Fi = F[i][0]

            rand_p = getRandNum(0, 1)
            # 变异改进
            if 0 <= rand_p <= rand_p_a:
                for j in range(len(P[0])):
                    np.random.shuffle(myindexs)
                    if iteration < 2:
                        T[i][j] = T[i][j] + Fi * (P[bestindex][j] - T[i][j]) + Fi * (
                                P[myindexs[0]][j] - P[myindexs[1]][j]) + Fi * (P[myindexs[2]][j] - P[myindexs[3]][j])
                        if T[i][j] >= VariablelistMin[j] and T[i][j] <= VariablelistMax[j]:
                            continue
                        else:
                            T[i][j] = getRandNum(VariablelistMin[j], VariablelistMax[j])
                    else:
                        T[i][j] = T[i][j] + Fi * (P[bestindexofJA][j] - T[i][j]) + Fi * (
                                P[myindexs[0]][j] - externalarchiveMatrix[randint(0, len(externalarchiveMatrix)) - 1][j])
                        if T[i][j] >= VariablelistMin[j] and T[i][j] <= VariablelistMax[j]:
                            continue
                        else:
                            T[i][j] = getRandNum(VariablelistMin[j], VariablelistMax[j])
                countselect1 += 1
                res1 = assess_fitness(Q[i])
                res2 = assess_fitness(T[i])
                if res2 - res1 < 0:
                    weight1 += (res1 - res2) / res1


            if rand_p_a < rand_p <= rand_p_b:
                for j in range(len(P[0])):
                    np.random.shuffle(myindexs)
                    T[i][j] = P[i][j] + Fi * (P[myindexs1[0]][j] - P[i][j]) + Fi * (P[myindexs1[1]][j] - P[myindexs1[2]][j])
                    if T[i][j] >= VariablelistMin[j] and T[i][j] <= VariablelistMax[j]:
                        continue
                    else:
                        T[i][j] = getRandNum(VariablelistMin[j], VariablelistMax[j])
                countselect2 += 1
                res1 = assess_fitness(Q[i])
                res2 = assess_fitness(T[i])
                if res2 - res1 < 0:
                    weight2 += (res1 - res2) / res1

            if rand_p_b < rand_p <= 1:
                for j in range(len(P[0])):
                    np.random.shuffle(myindexs)
                    rand_current = getRandNum(0, 1)
                    T[i][j] = T[i][j] + rand_current * (P[myindexs[0]][j] - T[i][j]) + Fi * (P[myindexs[1]][j] - P[myindexs[2]][j])
                    if T[i][j] >= VariablelistMin[j] and T[i][j] <= VariablelistMax[j]:
                        continue
                    else:
                        T[i][j] = getRandNum(VariablelistMin[j], VariablelistMax[j])
                countselect3 += 1
                res1 = assess_fitness(Q[i])
                res2 = assess_fitness(T[i])
                if res2 - res1 < 0:
                    weight3 += (res1 - res2) / res1


        return T, weight1, weight2, weight3, countselect1, countselect2, countselect3

    def getRandNum(a,b,pre=2,num=1):
        randNums = []
        for i in range(0,num):
            randNums.append(round(a + (b-a)*np.random.uniform(),pre))
        if len(randNums) == 1:
            return randNums[0]
        else:
            return randNums


    def getC():
        C = 0
        if np.random.rand()<0.5:
            C = 0.7*np.random.randn()
            while C>1 or C<0.5:
                C = 0.7*np.random.randn()
        else:
            C = 1+0.7*np.random.randn()
            while C>1 or C<0.5:
                C = 1+0.7*np.random.randn()

        return C

    def assess_fitness(X):
        Dim = len(X)
        if D == 10:
            X = np.dot(M10, np.transpose((X - O10) * 10))
            X = np.transpose(X)
        if D == 30:
            X = np.dot(M30, np.transpose((X - O30) * 10))
            X = np.transpose(X)
        if D == 50:
            X = np.dot(M50, np.transpose((X - O50) * 10))
            X = np.transpose(X)
        res = 0.
        for i in range(0, Dim - 1):
            X[i - 1] += 420.9687462275036
            if X[i] > 500:
                res -= (500 - X[i] % 500) * math.sin(math.pow((500 - X[i] % 500), 0.5))
                tmp = (X[i] - 500) / 100
                res += tmp * tmp / Dim
            elif X[i] < -500:
                res -= (-500 + X[i] % 500) * math.sin(math.pow((500 - abs(X[i]) % 500), 0.5))
                tmp = (X[i] + 500) / 100
                res += tmp * tmp / Dim
            else:
                res -= X[i] * math.sin(math.pow(abs(X[i]), 0.5))
        res += 418.9829 * Dim
        return res

    def computeTwoIndividual(ind1, ind2):
        ind1_fitness = assess_fitness(ind1)
        ind2_fitness = assess_fitness(ind2)
        a = 0

        if ind1_fitness < ind2_fitness:
            a = -1
            return ind1, a
        else:
            a = 1
            return ind2, a


    def computeFitness(VariablelistMatrix):
        fitnessMatrix = []
        for x in range(0,len(VariablelistMatrix)):
            current_individual = VariablelistMatrix[x]
            current_fitness = assess_fitness(current_individual)
            fitnessMatrix.append(current_fitness)

        bestFitness = min(fitnessMatrix)
        bestindex = fitnessMatrix.index(bestFitness)

        badFitnessList.append(max(fitnessMatrix))
        meanFitnessList.append(sum(fitnessMatrix)/len(fitnessMatrix))

        return bestindex,bestFitness,fitnessMatrix

    def CalculateDiversity(E):
        SumMidIndividual = np.zeros((1,10))
        SumDiversity = 0
        for i in range(len(E)):
            SumMidIndividual += np.array(E[i])
        MidIndividual = SumMidIndividual/len(E)
        for i in range(len(E)):
            SumDiversity += np.sqrt(np.sum(np.square(np.array(E[i])-np.array(MidIndividual))))/D
        Diversity = SumDiversity/len(E)
        return Diversity



    def onsnps_algorithm(popsize):
        start_time = getNowTimestamp()

        thresholdValue =0.00000001
        dpaList = []
        bestFitnessList = []
        Pjm = 0.95

        max_iteration = 10000*D
        iteration = 0
        popsizemin = 10
        unchangedTime = 0
        unchangedSolutionList = []
        unchangedSolution = 1
        unchangedVariable = []
        externalarchiveA = []
        externalarchiveMatrix = []
        DiversityList = []
        BestFitnessList = []
        GlobalDiversityList = []
        rand_p_a = 0.33
        rand_p_b = 0.66
        cs1 = 0
        cs2 = 0
        cs3 = 0
        sumW1 = 0
        sumW2 = 0
        sumW3 = 0
        # 初始生成MCR和MF
        MCR = 0.5 * (np.ones((popsize, 1)))
        MF = 0.5 * (np.ones((popsize, 1)))

        F = []
        for i in range(popsize):
            F.append(0.45)
        CR = []
        for i in range(popsize):
            CR.append(0.5)
        Fsigma = 0.1
        q = 0

        #                  x1,x2,x3....xD
        VariablelistMin = []
        VariablelistMax = []
        VariablelistDelta = []

        for x in range(0,D):
            VariablelistMin.append(-100)
            VariablelistMax.append(100)
            VariablelistDelta.append(0.01)


        recordIteration=[0.01, 0.02, 0.03, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
        recordIteration = [ i*max_iteration for i in recordIteration]

        VariablelistMatrix = getOriginVariableRandom(VariablelistMin, VariablelistMax, popsize)


        bestindex = randint(0, len(VariablelistMatrix)-1)
        best = VariablelistMatrix[bestindex]
        bestFitness = assess_fitness(best)
        fitnessMatrix = []


        bestindex,bestFitness,fitnessMatrix = computeFitness(VariablelistMatrix)
        best = VariablelistMatrix[bestindex]
        bestFitnessList.append(bestFitness)

        E = copy.deepcopy(VariablelistMatrix)
        dpaList.append(DpaByp(E, 0))

        while (True):
            SCR = []
            SF = []
            if iteration > max_iteration:
                break



            if abs(unchangedSolution-bestSolution) <= thresholdValue:
                break
            if bestFitness < 1.0e-8:
                break

            if unchangedTime == 500:
                Pjm = 0.8

            if iteration > 0:
                fitnessMatrix = []
                bestindex,bestFitness,fitnessMatrix = computeFitness(E)
                best = E[bestindex]
                bestFitnessList.append(bestFitness)
                dpaList.append(DpaByp(E, iteration))


                if iteration+1 in recordIteration:
                    caculationErrorList.append(bestFitness-bestSolution)


            popsizeg = len(E)
            popsizenext = round(((popsizemin-popsize)/max_iteration)*iteration+popsize)
            fitnessMatrix = np.array(fitnessMatrix)
            I1 = np.argsort(-fitnessMatrix)
            temp4 = -(popsizenext - popsizeg)
            while temp4 > 0:
                temp5 = randint(0, temp4)
                del E[I1[temp5]]
                temp4 = temp4 - 1


            T = copy.deepcopy(E)
            if iteration < max_iteration/2:
                for i in range(len(E)):
                    F[i] = 0.45 + 0.1 * random.random()
            else:
                for i in range(len(E)):
                    a = MF[i] + Fsigma * math.tan(math.pi * (random.random() - 0.5))
                    a = min(1, a)
                    F[i] = a
                    while F[i] <= 0:
                        a = MF[i] + Fsigma * math.tan(math.pi * (random.random() - 0.5))
                        a = min(1, a)
                        F[i] = a

            T, w1, w2, w3, countselect1, countselect2,countselect3 = makeVariation2(T,VariablelistMin,VariablelistMax,Pjm,VariablelistMatrix,externalarchiveMatrix,iteration,F,rand_p_a,rand_p_b)
            sumW1 += w1
            sumW2 += w2
            sumW3 += w3
            cs1 = cs1 + countselect1
            cs2 = cs2 + countselect2
            cs3 = cs3 + countselect3



            if iteration > 0 and iteration % 200 == 0:

                Rate = 1 - ((1 - rand_p_b) / (1 - rand_p_a))

                sumW1W2 = sumW2 + sumW3
                if sumW1 == sumW2 == sumW3 == 0 or sumW1 / (sumW1 + sumW1W2) == Wbia_a:
                    rand_p_a = rand_p_a
                else:
                    Pmax = 0.9
                    Pmin = 0.1
                    x = (sumW1 / (sumW1 + sumW1W2) - 0.33) / abs(sumW1 / (sumW1 + sumW1W2) - 0.33)
                    p = x * (Pmax - Pmin) / 2 + (Pmax + Pmin) / 2
                    delt = (p - rand_p_a) / 10
                    rand_p_a = rand_p_a + delt
                if (sumW2 / sumW3) == Wbia_b:
                    rand_p_b = rand_p_a + (1 - rand_p_a) * Rate
                else:
                    Pmax = 0.98
                    Pmin = rand_p_a + 0.02
                    x = (sumW2 / (sumW2 + sumW3) - Wbia_b) / abs(sumW2 / (sumW2 + sumW3) - Wbia_b)
                    p = x * (Pmax - Pmin) / 2 + (Pmax + Pmin) / 2
                    rand_p_b = rand_p_a + (1 - rand_p_a) * Rate
                    delt = (p - rand_p_b) / 10
                    rand_p_b = rand_p_b + delt
                    Wbia_a = cs1/(cs1+cs2+cs3)
                    Wbia_b = cs2/(cs2+cs3)

                cs1 = 0
                cs2 = 0
                cs3 = 0
                sumW1 = 0
                sumW2 = 0
                sumW3 = 0


            U = copy.deepcopy(E)
            for j in range(len(U)):
                r = randint(0, 99)
                a = MCR[r] + 0.1 * np.random.randn()
                a = max(0, a)
                a = min(1, a)
                CR[j] = a
                if np.random.rand() < CR[j] or j == 10:
                    U[j] = copy.deepcopy(T[j])

            numofsuccessevolution = 0
            for i in range(len(E)):
                A, a = computeTwoIndividual(E[i], U[i])
                E[i] = copy.deepcopy(A)

                if a == -1:
                    externalarchiveA.append(U[i])
                else:
                    numofsuccessevolution = numofsuccessevolution + 1

            while len(externalarchiveA) > len(U):
                del externalarchiveA[randint(0, len(externalarchiveA) - 1)]
            externalarchiveMatrix = copy.deepcopy(externalarchiveA + E)

            fitness = copy.deepcopy(fitnessMatrix)
            fitnessMatrix = []
            bestindex, bestFitness, fitnessMatrix = computeFitness(E)
            SCRindex = -9999
            sumf = 0
            for i in range(len(E)):
                if fitness[i] > fitnessMatrix[i]:
                    SCR.append(CR[i])
                    SF.append(F[i])
                    sumf1 = abs(fitness[i] - fitnessMatrix[i])
                    sumf = sumf + sumf1
                    if i == q:
                        SCRindex = i
                        b = abs(fitness[i] - fitnessMatrix[i])


            if len(SCR) != 0 and len(SF) != 0:
                if q == SCRindex:
                   a = np.array(CR[SCRindex])
                   a.shape = (1, 1)
                   c = np.array(F[SCRindex])
                   c.shape = (1, 1)
                   w = b / sumf
                   MCR[q] = sum(w * a[0] * a[0]) / sum(w * a[0])
                   MF[q] = sum(w * c[0] * c[0]) / sum(w * c[0])
                   q = q + 1
                   if q > len(E) - 1:
                      q = 0

            Diversity = CalculateDiversity(E)
            DiversityList.append(Diversity)
            bestindex, bestFitness, fitnessMatrix = computeFitness(E)
            BestFitnessList.append(bestFitness)
            if iteration == 100:
                DiversityInit = Diversity
            if iteration > 100:
                Pm = Diversity/DiversityInit

                if np.random.rand() > Pm:
                    IndivadualIndex = np.argsort(fitnessMatrix)
                    WorstIndex = IndivadualIndex[math.ceil(len(IndivadualIndex)*0.98):]

                    ArrE = np.array(E)
                    MaxColumnE = np.empty((1, D))
                    for i in range(len(E[0])):
                        MaxColumnE[0, i] = abs(max(ArrE[:, i])) * 20
                        MaxColumnE[0, i] = max(MaxColumnE[0, i], 100)
                    for i in range(len(WorstIndex)):
                        for j in range(len(E[0])):
                            if getRandNum(0,1) <= 0.2:
                               E[WorstIndex[i]][j] = getRandNum(-100, 100)*0.1






            if bestFitness < unchangedSolution:
                unchangedSolution=bestFitness
                unchangedVariable = best
                unchangedTime=0
            else:
                unchangedTime = unchangedTime+1

            unchangedSolutionList.append(unchangedSolution)
            iteration = iteration+1

            print(str(TIMES)+"--第" + str(iteration) + "次迭代：" + str(bestFitness) + "种群大小：" + str(len(E)) + "————rand_p_a = " + str(rand_p_a) + "————rand_p_b =" + str(rand_p_b)+"————多样性指数："+str(Diversity))

        Result = str("第" + str(iteration) + "次迭代：" + str(bestFitness) + "—————种群大小：" + str(len(E)) + "————多样性指数：" + str(Diversity))
        GlobalResultList.append(Result)


        matData = {"unchangedSolutionList":unchangedSolutionList,"BestFitneesList":BestFitnessList,"badFitnessList":badFitnessList,"meanFitnessList":meanFitnessList,"caculationErrorList":caculationErrorList,"DiversityList":DiversityList}
        savemat("./data/f10_D_JADE_6_8_"+str(D)+"_T"+str(TIMES)+".mat", matData)

        return best


    if __name__ == '__main__':
        #                  x1 , x2
        onsnps_algorithm(100)
for i in range(len(GlobalResultList)):
    print(GlobalResultList[i])


